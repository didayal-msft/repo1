[DscResource()]
class nxscriptclass {
    [DscProperty(Key)] [customscriptScope]
    $ConfigurationScope

    [DscProperty(Mandatory)] [string]
    $getscript

    [DscProperty(Mandatory)][string]
    $setscript

    [DscProperty(Mandatory)][string]
    $testscript
    
    [DscProperty()]
    [Reason[]] $Reasons


    [bool] Test() {
        $logfile = "/tmp/testdsclog.log"
        "[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null
        $rnd = Get-Random -Minimum 100 -Maximum 999
        "$($this.testscript)" | out-file "\tmp\testscript$rnd$(".sh")" -force
        Set-Location \tmp
        [int]$res = Invoke-Expression "sudo sh testscript$rnd.sh"
        "[$(get-date)]executed test script. Result: $res" | out-file $logfile -Append -Force | out-null       
        Remove-Item "\tmp\testscript$rnd$(".sh")" -force
        "[$(get-date)]removed script \tmp\testscript$rnd$(".sh")" | out-file $logfile -Append -Force | out-null
        return $res
    }

    [void] Set() {
        $logfile = "/tmp/setdsclog.log"
        "[$(get-date)]starting set script" | out-file $logfile -Append -Force | out-null
        $rnd = Get-Random -Minimum 100 -Maximum 999
        "$($this.setscript)" | out-file "\tmp\setscript$rnd$(".sh")" -force | out-null
        Set-Location \tmp
        $res = Invoke-Expression "sudo sh setscript$rnd.sh" | out-null
        "[$(get-date)]executed set script. Result: $res" | out-file $logfile -Append -Force | out-null
        Remove-Item "\tmp\setscript$rnd$(".sh")" -force -ea SilentlyContinue | out-null
        "[$(get-date)]removed set script" | out-file $logfile -Append -Force | out-null
            
    }
    [nxscriptclass] Get() {
        $logfile = "/tmp/getdsclog.log"
        if ([string]::IsNullOrEmpty($this.GetScript)) {
            "[$(get-date)]get script null" | out-file $logfile -Append -Force | out-null
            $Reason = [Reason]::new()
            $Reason.Code = "Script:Script:GetScriptOutput"
            $Reason.Phrase = "No Get Script defined"
            $this.Reasons = @($Reason)
            return $this
        }
        else {
            $rnd = Get-Random -Minimum 100 -Maximum 999
            "[$(get-date)]starting get script" | out-file $logfile -Append -Force | out-null
            "$($this.getscript)" | out-file "\tmp\getscript$rnd$(".sh")" -force
            Set-Location \tmp
            try {
                $res = Invoke-Expression "sudo sh getscript$rnd.sh" 
                "[$(get-date)]executed get script output:$res" | out-file $logfile -Append -Force | out-null
                $Reason = [Reason]::new()
                $Reason.Code = "Script:Script:GetScriptOutput"
                $Reason.Phrase = "$res"
                $this.Reasons = @($Reason)
                return $this
            }
            catch {
                $Reason = [Reason]::new()
                $Reason.Code = "Script:Script:GetScriptOutput"
                $Reason.Phrase = "$($_)"
                $this.Reasons = @($Reason)                
                "[$(get-date)]failed get script $_" | out-file $logfile -Append -Force | out-null
                return $this
                
            }
            finally {
                <#Do this after the try block regardless of whether an exception occurred or not#>
                Remove-Item "\tmp\getscript$rnd$(".sh")" -force
                "[$(get-date)]removed get script" | out-file $logfile -Append -Force | out-null
            }
           
        }
       
    }
      
}

class Reason {
    [DscProperty()]
    [string] $Code
    
    [DscProperty()]
    [string] $Phrase
}

enum customscriptScope {
    Machine
    User
}
