[DscResource()]
class nxscriptclass {
    [DscProperty(Key)] [customscriptScope]
    $ConfigurationScope

    [DscProperty(Mandatory)] [string]
    $getscript

    [DscProperty(Mandatory)][string]
    $setscript

    [DscProperty(Mandatory)][string]
    $testscript

    hidden [nxscriptclass] $CachedCurrentState
    hidden [PSCustomObject] $CachedData

    [bool] Test() {
        #$CurrentState = $this.Get()
        #write-host $this.testscript
        "$($this.testscript)" | out-file .\testscript.sh -force
        [int]$res = Invoke-Expression "sudo sh testscript.sh"
        return $res
     }

    [void] Set() {
        "$($this.setscript)" | out-file .\setscript.sh -force
        [int]$res = Invoke-Expression "sudo sh setscript.sh" | out-null
            
        }
    [nxscriptclass] Get() 
        {
            $CurrentState = [nxscriptclass]::new()
            #write-verbose "executing the get script"
            "$($this.getscript)" | out-file .\getscript.sh -force
            $res = Invoke-Expression "sudo sh getscript.sh" | out-null
            $CurrentState.ConfigurationScope = $this.ConfigurationScope

            $this.CachedCurrentState = $CurrentState
        
            return $CurrentState
            return $CurrentState
        }
      
    }

    enum customscriptScope {
    Machine
    User
}

