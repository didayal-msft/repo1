Configuration ACP_IMS_Config_Linux
{
    param (
	    [Parameter(Mandatory)]
        [String]
        $StorageAccountName,
		
		[Parameter(Mandatory)]
        [String]
        $DSCIdentityClientId,
		
		[Parameter(Mandatory)]
        [String]
        $Inventory_ContainerUri
    )
	
    Import-DscResource -ModuleName 'qualys/qualys.psd1'
	Import-DscResource -ModuleName 'nxinternal/customresources.psd1'
	
	Node localhost
    {
	    acp-ims-endpoint-linux config
		{
		    StorageAccountName = "$StorageAccountName"
			DSCIdentityClientId = "$DSCIdentityClientId"
		}
		
		acp-ims-backup-linux config
		{
		    StorageAccountName = "$StorageAccountName"
			DSCIdentityClientId = "$DSCIdentityClientId"
		}
		
		acp-ims-splunk-linux config
		{
		    StorageAccountName = "$StorageAccountName"
			DSCIdentityClientId = "$DSCIdentityClientId"
		}
		
		acp-ims-qualys-linux config
        {
            StorageAccountName = "$StorageAccountName"
            DSCIdentityClientId = "$DSCIdentityClientId"
        }
		
		acp-ims-tanium-linux config
        {
            StorageAccountName = "$StorageAccountName"
            DSCIdentityClientId = "$DSCIdentityClientId"
        }
		
		acp-ims-audit-linux config
        {
            StorageAccountName = "$StorageAccountName"
            DSCIdentityClientId = "$DSCIdentityClientId"
            Inventory_ContainerUri = "$Inventory_ContainerUri"
        }
	}
}