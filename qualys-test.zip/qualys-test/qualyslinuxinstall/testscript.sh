  #!/bin/bash
  isTagPresent=false
  
  # If Qualys Tag is absent then return 'true', since the node does 
  # not have to be configured for Qualys and hece Set-Script is not to be  invoked
  
  tags=$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute/tags?api-version=2019-08-15&format=text" | tr ";" "\n")
  
  for tag in $tags
  do
      if [ "$tag" = "acp-ims-qualys:yes" ]; then
          isTagPresent=true
          break
      fi
  done
  
  if $isTagPresent; then
    echo "Instance tagged with acp-ims-qualys:yes. Check Qualys Status" >> /var/log/Qualys-log.txt
    
    if cat /etc/os-release |grep -i 'Ubuntu' > /dev/null 2>&1; then
        dpkg -s qualys-cloud-agent > /dev/null 2>&1 >> /var/log/Qualys-log.txt
        rc=$?
     else
        rpm -qa | grep qualys-cloud-agent >> /var/log/Qualys-log.txt
        rc=$?
     fi
  
    if [ $rc -eq 0 ] ; then
      echo "Qualys CloudAgent is already installed" >> /var/log/Qualys-log.txt
      echo 1
    else
      echo "Qualys CloudAgent is not installed" >> /var/log/Qualys-log.txt
      echo 0
    fi
  else
    # Tag is not present, hence Qualys CloudAgent is not to be installed
    echo "Instance not tagged with acp-ims-qualys:yes" >> /var/log/Qualys-log.txt
    echo 0
  fi
