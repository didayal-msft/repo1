
/home/divyadeep/dscdev/qualys/Helpers.ps1
import-module psdesiredstateconfiguration
import-module /home/divyadeep/dscdev/qualys/nxinternal/nxinternal.psd1

$StorageAccountName ="ddsharedstorage"
$PackageDownloadPath = "/tmp/Qualys"
$LogFileLocation = "/var/log"
$packagefilePath = "https://$StorageAccountName.blob.core.windows.net/package/acp-ims-qualys/version-1"
$config_file_Path = "https://$StorageAccountName.blob.core.windows.net/configurations"
$scriptPath = "https://$StorageAccountName.blob.core.windows.net/common"
$script_Name = "common_lin_qualys.sh"
$script_Url = "$scriptPath/$script_Name"
$LogFile = "$LogFileLocation/Qualys-log.txt"
$ErrorLog = "$LogFileLocation/Qualys-error-log.txt"
$tagNameValue = "acp-ims-qualys:yes"
$tagNameValueUninstall = "acp-ims-qualys:no"
$DSCIdentityClientId = "595093fd-4fd6-4d53-a9c8-9577ab6e7499"

configuration qualyslinuxinstall {
  
  import-dscresource -modulename /home/divyadeep/dscdev/qualys/nxinternal/nxinternal.psd1

  nxscriptclass installqualys {
  ConfigurationScope = 'Machine'
  setscript = @"
  #!/bin/bash
  log_file="$LogFile"
  error_log="$ErrorLog"
  client_id="$DSCIdentityClientId"
  package_path="$packagefilePath"
  package_download_path="$PackageDownloadPath"
  configfilePath="$config_file_Path"
  scriptName="$script_Name"
  scriptUrl="$script_Url"
"@ + @'

  echo "Installing Qualys CloudAgent" >> $log_file
  mkdir -p $package_download_path
  cd "${package_download_path}"
  
  if ( cat /etc/*release | grep 'Red Hat Enterprise Linux Server release 7.9\|Red Hat Enterprise Linux release 8.2\|Red Hat Enterprise Linux release 8.4\|Red Hat Enterprise Linux release 8.5\|CentOS Linux release 7.9\|Ubuntu 18.04\|Ubuntu 20.04\|SUSE Linux Enterprise Server 12 SP5\|SUSE Linux Enterprise Server 15 SP3' )
  then
  echo "Supported Linux version" >> $log_file
  else
  echo "Unsupported Linux version" >> $log_file
  exit 1
  fi
  
  echo "Downloading common script file" >> $log_file
  
  
  #Get the access token
  oauth_url="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fstorage.azure.com%2F&client_id=$client_id"
  
  access_token=`curl -s $oauth_url -H Metadata:true | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"access_token\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  
  status=`curl -Is "$scriptUrl"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head -n 1`
  if echo "$status" | grep -q 404
  then
  echo "Script file missing from the storage container: $scriptUrl . Please upload the script file." >> $log_file
  exit 1
  elif echo "$status" | grep -q 200
  then
  file_flag="true"
  else
  echo "Unable to download the script file from the storage container: $scriptUrl. Please check permissions to access the storage container" >> $log_file
  exit 1
  fi
  
  if [ -f $package_download_path/$scriptName ]; then
  
  blobstatus=`curl -Is "$scriptUrl"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head | grep ^Last-Modified | awk {'print $3,$4,$5,$6,$7'}`
  
  blobdate=$(date -d "$blobstatus" "+%Y%m%d%H%M%S")
  
  blobdatetime=$(echo "$blobdate" | sed -re 's/^([0-9]{8})([0-9]{2})([0-9]{2})([0-9]{2})$/\1\\ \2:\3:\4/' | xargs date -u -d)
  
  blobtime=$(date "+%s" -d "$blobdatetime")
  
  file="$package_download_path/$scriptName"
  local=$(stat $file | grep "Modify"| awk '{print $2,$3}')
  
  localdate=$(date -d "$local" "+%Y%m%d%H%M%S")
  
  localdatetime=$(echo "$localdate" | sed -re 's/^([0-9]{8})([0-9]{2})([0-9]{2})([0-9]{2})$/\1\\ \2:\3:\4/' | xargs date -u -d)
  
  localtime=$(date "+%s" -d "$localdatetime")
  
  if [ $blobtime -gt $localtime ]
  then
  download_flag="true"
  echo "flag set" >> $log_file
  fi
  else
  download_flag="true"
  echo "script not in VM" >> $log_file
  fi
  
  if [ $download_flag = 'true' ]; then
  
  cd $package_download_path
  
  echo "Downloading the script file $scriptName from $scriptUrl" >> $log_file
  
  curl -L -o "$scriptName" "$scriptUrl" -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" >> $log_file
  fi
  
  if [ -f $package_download_path/$scriptName ]; then
  
  echo "Completed Downloading script file" >> $log_file
  echo "changing permission to script file" >> $log_file
  chmod +x $package_download_path/$scriptName
  
  . "$package_download_path/$scriptName"
  installerName=`qualysinstallerName`
  echo "installer in wrapper $installerName"
  package_download_url="$package_path/$installerName"
  
  if cat /etc/os-release |grep -i 'Ubuntu'; then
     dpkg -s qualys-cloud-agent
     rc=$?
  else
     rpm -qa | grep qualys-cloud-agent
     rc=$?
  fi
  
  if [ $rc -ne 0 ] ; then
  
  if [ ! -f $package_download_path/$installerName ]; then
  #Get the access token
  oauth_url="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fstorage.azure.com%2F&client_id=$client_id"
  
  access_token=`curl -s $oauth_url -H Metadata:true | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"access_token\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  
  status=`curl -Is "$package_download_url"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head -n 1`
  if echo "$status" | grep -q 404
  then
  echo "Installer file missing from the storage container: $package_download_url. Please upload the installer file." >> $log_file
  exit 1
  elif echo "$status" | grep -q 200
  then
  echo "Downloading the installer file $installerName" >> $log_file
  curl -L -o "$installerName" "$package_download_url" -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" >> $log_file
  else
  echo "Unable to download the installer file from the storage container: $package_download_url. Please check permissions to access the storage container" >> $log_file
  exit 1
  fi
  fi
  
  if [ -f $package_download_path/$installerName ]; then
  
  installerFile="$package_download_path/$installerName"
  
  . "$package_download_path/$scriptName"
  QualysSHA512=`qualyschecksum`
  export Installersha512sum="$QualysSHA512"
  
  echo "checksum $Installersha512sum" >> $log_file
  
  # checking sha512sum value
  if [[ -z $Installersha512sum ]] ; then
    echo "Error Installersha512sum not passed" >> $log_file
    exit 1
  fi
  
  #Generate the sha512sum value of the locally downloaded copy of installer
  shachecksum=`sha512sum $installerFile | awk '{ print $1 }'`
  
  if [[ $shachecksum != $Installersha512sum ]] ; then
      echo "Error validating the checksum for the $installerName" >> $log_file
      rm -f $installerFile     
      exit 1
  fi
  
  echo "Downloaded the installer file" >> $log_file
  . "$package_download_path/$scriptName"
  echo "opening script file" >> $log_file
  install_qualys
  fi
  
  else
  
  echo "Qualys CloudAgent is already installed"
  Provider_Nodename=`curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute/vmId?api-version=2019-08-15&format=text"`
  
  configfileName="acp-ims-qualys-${Provider_Nodename}.json"
  
  #Get the access token
  oauth_url="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fstorage.azure.com%2F&client_id=$client_id"
  
  access_token=`curl -s $oauth_url -H Metadata:true | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"access_token\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  
  configfileUrl="$configfilePath/$configfileName"
  configfile="$package_download_path/$configfileName"
  
  status=`curl -Is "$configfileUrl"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head -n 1`
  if echo "$status" | grep -q 404
  then
  echo "Config file is missing.Hence skipping the proxy configuration setup" >> $log_file
  configfile_check="missing"
  elif echo "$status" | grep -q 200
  then
  echo "Downloading the config file acp-ims-qualys-${Provider_Nodename}" >> $log_file
  curl -L -o "$configfileName" "$configfileUrl" -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" >> $log_file
  echo "Config file downloaded" >> $log_file
  configfile_check="present"
  else
  echo "Unable to download the config file from the storage container: $configfileUrl. Please check permissions to access the storage container" >> $log_file
  exit 1
  fi
  echo "flag for config $configfile_check after the loop" >> $log_file
  if [ "$configfile_check" == "present" ] ; then
  flag="Nochange"
  proxy_config="$(grep -oP '(?<="proxy_config": ")[^"]*' $configfile)"
  
  . "$package_download_path/$scriptName"
  proxy_path
  if [ "$proxy_config" == "Authenticated" ] ; then 
  . "$package_download_path/$scriptName"
  
  # Get the Access token for KeyVault
  subId=`curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute/subscriptionId?api-version=2019-08-15&format=text"`
  resourceIdKV="https://vault.azure.net"
  oauth_url="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=$resourceIdKV&client_id=$client_id"
  
  access_token=`curl -s $oauth_url -H Metadata:true | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"access_token\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  
  keyvaultname="acpcms${subId:0:8}${subId: -8}kv"
  cproxyurl="acp-ims-auth-proxy-url"
  cproxyuname="acp-ims-auth-proxy-username"
  cproxypwd="acp-ims-auth-proxy-password"
  vaulturlurl="https://$keyvaultname.vault.azure.net/secrets/$cproxyurl"
  proxy_url=`curl "$vaulturlurl"?api-version=2016-10-01 -H "Authorization: Bearer $access_token" | cut -d\" -f4`
  echo "$proxy_url" >> $log_file
  . "$package_download_path/$scriptName"
  proxyconfig_Y
  vaulturluname="https://$keyvaultname.vault.azure.net/secrets/$cproxyuname"
  proxy_username=`curl "$vaulturluname"?api-version=2016-10-01 -H "Authorization: Bearer $access_token" | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"value\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  echo "$proxy_username" >> $log_file
  vaulturlpswd="https://$keyvaultname.vault.azure.net/secrets/$cproxypwd"
  param_value=`curl "$vaulturlpswd"?api-version=2016-10-01 -H "Authorization: Bearer $access_token" | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"value\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`
  
  if [ "$param_value" == '' ] ; then
  echo 'Key vault value for the proxy configuration is missing in the key vault, please check the parameter store to sort it'
  exit 1
  fi
  
  . "$package_download_path/$scriptName"
  proxywith_usercred_Y
  
  elif [ "$proxy_config" == "None" ] ; then
  . "$package_download_path/$scriptName"
  proxyconfig_N
  fi
  . "$package_download_path/$scriptName"
  service_restart
  fi
  fi
  fi
'@
  
testscript = @"
  #!/bin/bash
  isTagPresent=false
  
  # If Qualys Tag is absent then return 'true', since the node does 
  # not have to be configured for Qualys and hece Set-Script is not to be  invoked
  
  tags=`$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute/tags?api-version=2019-08-15&format=text" | tr ";" "\n")
  
  for tag in `$tags
  do
      if [ "`$tag" = "$tagNameValue" ]; then
          isTagPresent=true
          break
      fi
  done
  
  if `$isTagPresent; then
    echo "Instance tagged with $tagNameValue. Check Qualys Status" >> $LogFile
    
    if cat /etc/os-release |grep -i 'Ubuntu' > /dev/null 2>&1; then
        dpkg -s qualys-cloud-agent > /dev/null 2>&1 >> $LogFile
        rc=`$?
     else
        rpm -qa | grep qualys-cloud-agent >> $LogFile
        rc=`$?
     fi
  
    if [ `$rc -eq 0 ] ; then
      echo "Qualys CloudAgent is already installed" >> $LogFile
      echo 1
    else
      echo "Qualys CloudAgent is not installed" >> $LogFile
      echo 0
    fi
  else
    # Tag is not present, hence Qualys CloudAgent is not to be installed
    echo "Instance not tagged with $tagNameValue" >> $LogFile
    echo 0
  fi
"@
  
getscript = @'
  #!/bin/bash
echo 1
'@   
}
}


qualyslinuxinstall  