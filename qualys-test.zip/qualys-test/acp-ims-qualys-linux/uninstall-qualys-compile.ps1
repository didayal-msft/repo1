
/home/divyadeep/dscdev/qualys/Helpers.ps1
import-module psdesiredstateconfiguration
import-module /home/divyadeep/dscdev/qualys/nxinternal/nxinternal.psd1

$StorageAccountName ="ddsharedstorage"
$PackageDownloadPath = "/tmp/Qualys"
$LogFileLocation = "/var/log"
$packagefilePath = "https://$StorageAccountName.blob.core.windows.net/package/acp-ims-qualys/version-1"
$config_file_Path = "https://$StorageAccountName.blob.core.windows.net/configurations"
$scriptPath = "https://$StorageAccountName.blob.core.windows.net/common"
$script_Name = "common_lin_qualys.sh"
$script_Url = "$scriptPath/$script_Name"
$LogFile = "$LogFileLocation/Qualys-log.txt"
$ErrorLog = "$LogFileLocation/Qualys-error-log.txt"
$tagNameValue = "acp-ims-qualys:yes"
$tagNameValueUninstall = "acp-ims-qualys:no"
$DSCIdentityClientId = "595093fd-4fd6-4d53-a9c8-9577ab6e7499"

configuration qualyslinuxuninstall {
  
  import-dscresource -modulename /home/divyadeep/dscdev/qualys/nxinternal/nxinternal.psd1

  nxscriptclass installqualys {
  ConfigurationScope = 'Machine'
  setscript = @"
#!/bin/bash
log_file="$LogFile"
client_id="$DSCIdentityClientId"
error_log="$ErrorLog"
package_download_path="$PackageDownloadPath"
scriptName="$script_Name"
scriptUrl="$script_Url"

"@ + @'

if ( cat /etc/*release | grep 'Red Hat Enterprise Linux Server release 7.9\|Red Hat Enterprise Linux release 8.2\|Red Hat Enterprise Linux release 8.4\|Red Hat Enterprise Linux release 8.5\|CentOS Linux release 7.9\|Ubuntu 18.04\|Ubuntu 20.04\|SUSE Linux Enterprise Server 12 SP5\|SUSE Linux Enterprise Server 15 SP3' )
then
echo "Supported Linux version" >> $log_file
else
echo "Unsupported Linux version" >> $log_file
exit 1
fi

download_flag="false"

if cat /etc/os-release |grep -i 'Ubuntu'; then
   dpkg -s qualys-cloud-agent
   rc=$?
else
   rpm -qa | grep qualys-cloud-agent
   rc=$?
fi

if [ $rc -eq 0 ] ; then

mkdir -p $package_download_path
cd "${package_download_path}"

echo "Downloading common script file" >> $log_file


#Get the access token
oauth_url="http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Fstorage.azure.com%2F&client_id=$client_id"

access_token=`curl -s $oauth_url -H Metadata:true | sed -e 's/[{}]/''/g' |  awk -v k="text" '{n=split($0,a,","); for (i=1; i<=n; i++) print a[i]}' |  grep -i \"access_token\" | cut -d ':' -f2 | sed -e 's/^"//' -e 's/"$//'`

status=`curl -Is "$scriptUrl"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head -n 1`
if echo "$status" | grep -q 404
then
echo "Script file missing from the storage container: $scriptUrl. Please upload the script file." >> $log_file
exit 1
elif echo "$status" | grep -q 200
then
file_flag="true"
else
echo "Unable to download the script file from the storage container: $scriptUrl. Please check permissions to access the storage container" >> $log_file
exit 1
fi

if [ -f $package_download_path/$scriptName ]; then

blobstatus=`curl -Is "$scriptUrl"  -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" | head | grep ^Last-Modified | awk {'print $3,$4,$5,$6,$7'}`

blobdate=$(date -d "$blobstatus" "+%Y%m%d%H%M%S")

blobdatetime=$(echo "$blobdate" | sed -re 's/^([0-9]{8})([0-9]{2})([0-9]{2})([0-9]{2})$/\1\\ \2:\3:\4/' | xargs date -u -d)

blobtime=$(date "+%s" -d "$blobdatetime")

file="$package_download_path/$scriptName"
local=$(stat $file | grep "Modify"| awk '{print $2,$3}')

localdate=$(date -d "$local" "+%Y%m%d%H%M%S")

localdatetime=$(echo "$localdate" | sed -re 's/^([0-9]{8})([0-9]{2})([0-9]{2})([0-9]{2})$/\1\\ \2:\3:\4/' | xargs date -u -d)

localtime=$(date "+%s" -d "$localdatetime")

if [ $blobtime -gt $localtime ]
then
download_flag="true"
fi
else
download_flag="true"
echo "script not in VM" >> $log_file
fi

if [ $download_flag = 'true' ]; then

cd $package_download_path

echo "Downloading the script file $scriptName from $scriptUrl" >> $log_file

curl -L -o "$scriptName" "$scriptUrl" -H "x-ms-version: 2017-11-09" -H "Authorization: Bearer $access_token" >> $log_file
fi

if [ -f $package_download_path/$scriptName ]; then
echo "Completed Downloading script file" >> $log_file
echo "changing permission to script file" >> $log_file
chmod +x $scriptName
. "$package_download_path/$scriptName"
uninstall_qualys
fi

fi
'@

testscript = @"
#!/bin/bash
isTagPresent=false

# If Qualys Tag is absent then return 'true', since the node does 
# not have to be configured for Qualys and hence Set-Script is not to be invoked

tags=`$(curl -s -H Metadata:true "http://169.254.169.254/metadata/instance/compute/tags?api-version=2019-08-15&format=text" | tr ";" "\n")
for tag in `$tags
do
  if [ "`$tag" = "$tagNameValueUninstall" ]; then
      isTagPresent=true
      break
  fi
done

if `$isTagPresent; then
echo "Instance tagged with $tagNameValueUninstall. Check if Qualys CloudAgent is installed" >> $LogFile
if cat /etc/os-release |grep -i 'Ubuntu' > /dev/null 2>&1 ; then
    dpkg -s qualys-cloud-agent > /dev/null 2>&1 >> $LogFile
    rc=`$?
 else
    rpm -qa | grep qualys-cloud-agent >> $LogFile
    rc=`$?
 fi

if [ `$rc -eq 0 ] ; then
  echo "Qualys CloudAgent is installed and tag is set to no" >> $LogFile
  echo 0
else
  echo "Qualys CloudAgent is not installed and tag is set to no" >> $LogFile
echo 1
fi
else
# Tag is not present, hence Qualys is not to be uninstalled
echo "Instance not tagged with $tagNameValueUninstall" >> $LogFile
echo 0
fi
"@

getscript = @'
#!/bin/bash
if cat /etc/os-release |grep -i 'Ubuntu'; then
  dpkg -s qualys-cloud-agent >> $LogFile
else
  rpm -qa | grep qualys-cloud-agent >> $LogFile
fi
'@         

    }
}



qualyslinuxuninstall