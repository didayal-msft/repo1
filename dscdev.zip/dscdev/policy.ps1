# Create a package that will audit and apply the configuration (Set)
./Helpers.ps1
Import-module ./CustomResources/CustomResources.psd1
$params = @{
    Name          = 'createsetworkfile'
    Configuration = './createsetworkfile/createsetworkfile.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params

Expand-Archive -Path .\createsetworkfile.zip -DestinationPath createsetworkzipfile

Get-ChildItem -Recurse -Path .\createsetworkzipfile |
    Measure-Object -Sum Length |
    ForEach-Object -Process {
        $Size = [math]::Round(($_.Sum / 1MB), 2)
        "$Size MB"
    }


    # Get the current compliance results for the local machine
sudo pwsh -command 'Get-GuestConfigurationPackageComplianceStatus -Path ./createsetworkfile.zip'
