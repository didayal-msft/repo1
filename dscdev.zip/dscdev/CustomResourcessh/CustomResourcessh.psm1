[DscResource()]
class customscriptsh {
    [DscProperty(Key)] [customscriptScope]
    $ConfigurationScope

    [DscProperty(Mandatory)] [string]
    $getscript

    [DscProperty(Mandatory)][string]
    $setscript

    [DscProperty(Mandatory)][string]
    $testscript

    [DscProperty()][string]
    $getdetails

    hidden [customscriptsh] $CachedCurrentState
    hidden [PSCustomObject] $CachedData

    [bool] Test() {
        #$CurrentState = $this.Get()
        #write-host $this.testscript
        "$($this.testscript)" | out-file .\testscript.sh -force
        [int]$res = Invoke-Expression "sh testscript.sh"
        return $res
     }

    [void] Set() {
        "$($this.setscript)" | out-file .\setscript.sh -force
        [int]$res = Invoke-Expression "sh setscript.sh"
            
        }
    [customscriptsh] Get() 
        {
            $CurrentState = [customscriptsh]::new()
            #write-verbose "executing the get script"
            "$($this.getscript)" | out-file .\getscript.sh -force
            $res = Invoke-Expression "sh getscript.sh"
            
            $CurrentState.getdetails = $res
            return $CurrentState
        }

       
    }


enum customscriptScope {
    Machine
    User
}

