      #/bin/bash        
        File=/tmp/dscdev1/setworks.txt  
if test -f "$File"; then  
#echo "$File exist " 
echo 1
else
    #echo "does not exist $File" 
    echo 0
fi