./Helpers.ps1

import-module ./CustomResources/CustomResources.psd1

$DesiredState = @{
    Name     = 'customscript'
    Module   = 'CustomResources'
    Property = @{
        ConfigurationScope = 'Machine'
        getscript        = @"
        ls /tmp/dscdev/ | wc -l
"@

        setscript = @'
        mkdir /tmp/dscdev
        touch /tmp/dscdev/setworks.txt
'@
        #testscript = "test-path /tmp/dscdev/setworks.txt"
        #testscript ="bash /tmp/dscdev/test.sh"
        testscript = @'
        #/bin/bash        
        File=/tmp/dscdev/setworks.txt  
if test -f "$File"; then  
#echo "$File exist " 
echo 1
else
    #echo "does not exist $File" 
    echo 0
fi  
'@        

    }
}
Invoke-DscResource @DesiredState -Method Get
#Invoke-DscResource @DesiredState -Method Set -Verbose
#Invoke-DscResource @DesiredState -Method Test -Verbose



configuration createsetworkfile
    {
        Import-DSCResource -module ./CustomResources/CustomResources.psd1
        customscript createsetworkfile {
            ConfigurationScope = 'Machine'
            getscript        = @"
            ls /tmp/dscdev/ | wc -l
"@
    
            setscript = @'
            mkdir /tmp/dscdev
            touch /tmp/dscdev/setworks.txt
'@
            #testscript = "test-path /tmp/dscdev/setworks.txt"
            #testscript ="bash /tmp/dscdev/test.sh"
            testscript = @'
            #/bin/bash        
            File=/tmp/dscdev/setworks.txt  
    if test -f "$File"; then  
    #echo "$File exist " 
    echo 1
    else
        #echo "does not exist $File" 
        echo 0
    fi  
'@         
    
        }

    }

createsetworkfile







# #Get-Content -Path /tmp/dscdev/setworks.txt


# Invoke-DscResource @DesiredState -Method Get -Verbose
# Invoke-DscResource @DesiredState -Method Set -Verbose


# Invoke-DscResource @DesiredState -Method Get
# Invoke-DscResource @DesiredState -Method Test -Verbose
# Invoke-DscResource @DesiredState -Method Set
# Invoke-DscResource @DesiredState -Method Test
# Invoke-DscResource @DesiredState -Method Get

# Test-Path -Path /tmp/dscdev/setworks.txt

