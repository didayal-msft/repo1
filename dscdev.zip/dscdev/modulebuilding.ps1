#Create folder for the module
New-Item -Path './CustomResources' -ItemType Directory

#create module files
$ModuleSettings = @{
    RootModule           = 'CustomResources.psm1'
    DscResourcesToExport = 'customscript'  #DscResourcesToExport this setting specifies the DSC Resources that the module exports. You can use this setting to restrict the class-based DSC Resources that are exported by the module. It can remove DSC Resources from the list of exported module members, but it can't add DSC Resources to the list.
}

New-ModuleManifest -Path ./CustomResources.psd1 @ModuleSettings 
Get-Module -ListAvailable -Name ./CustomResources.psd1 | Format-List


New-Item -Path ./CustomResources.psm1  #Root Module file
New-Item -Path ./Helpers.ps1

. ./Helpers.ps1
Get-DscResource -Name customscript -Module CustomResources | Format-List
Get-DscResource -Name customscript -Module CustomResources -Syntax

