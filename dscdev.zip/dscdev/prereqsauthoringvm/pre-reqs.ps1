param([bool]$install)
#save guestconfiguration and nxtools modules to a predefined folder
if($install)
    {
        save-Module -Name GuestConfiguration -Path /tmp/dscdev/modules
        save-Module -Name nxtools -Path /tmp/dscdev/modules
        save-Module -Name PSDesiredStateConfiguration -RequiredVersion 3.0.0-beta1 -Path /tmp/dscdev/modules -AllowPrerelease
        save-module -Name psdscresources -Path /tmp/dscdev/modules
    }

#add /tmp/dscdev/modules to module path list
$env:PSModulePath += ":/tmp/dscdev/modules"

#import modules
import-module nxtools
import-module GuestConfiguration
import-module PSDesiredStateConfiguration
import-module psdscresources
