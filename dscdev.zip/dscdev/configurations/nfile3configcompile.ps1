
/home/azureuser/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

$env:PSModulePath += ":$pwd"

configuration nfile3 {

    import-dscresource -modulename nxtools
      
    nxscript nfile3script {
        setscript = @'
            
            $logfile = "/tmp/setdsclog.log"
            $scriptname="createfile_set.sh"
            $workingdir="/tmp/dscops"

            "[$(get-date)]starting set script" | out-file $logfile -Append -Force | out-null

            $scriptbody = @"
            touch nfile3.txt
"@

        if (!test-path $workingdir) { new-item $workingdir -ItemType Directory | out-null }
        $scriptbody | out-file "$workingdir/$scriptname" -Force
        "[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        "[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

        Invoke-NativeCommand -Executable 'bash' -Parameters @("$workingdir/$scriptname") | out-null

'@


testscript = @'

$logfile = "/tmp/testdsclog.log"
$scriptname="createfile_test.sh"
$workingdir="/tmp/dscops"

"[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null

$scriptbody = @"
if test -f /tmp/nfile3.txt; then
    echo "1"
else
    echo "0"
fi

"@

if (!test-path $workingdir) { new-item $workingdir -ItemType Directory | out-null }
$scriptbody | out-file "$workingdir/$scriptname" -Force
"[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
"[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

[bool]$res=$false
$res=Invoke-NativeCommand -Executable 'bash' -Parameters @("$workingdir/$scriptname") | out-null
return $res
'@


getscript = ""

    }
}

nfile3

rename-item ./nfile3/localhost.mof  nfile3.mof
