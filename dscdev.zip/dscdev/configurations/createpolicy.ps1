$container = get-azstorageaccount -Name ddsharedstorage -resourcegroupname sharedstorage | get-AzStorageContainer -Name machine-configuration

 $context = $container.Context



function createpolicy
    {
        param($context,$policyname,$zipfilepath,$containername,$policypath,$tagname)
     if($tagname)
     {   
    $tags=@{
        $tagname = "yes"
    }
}
    $setParams = @{
        Container = $containername
        File      = $zipfilepath
        Context   = $context
    }
    $blob = Set-AzStorageBlobContent @setParams
    $contentUri = $blob.ICloudBlob.Uri.AbsoluteUri

    $startTime = Get-Date
$endTime   = $startTime.AddYears(3)
$blob=$zipfilepath.split("/")[-1]
$tokenParams = @{
    StartTime  = $startTime
    ExpiryTime = $endTime
    Container  = $containername
    Blob       = $blob
    Permission = 'r'
    Context    = $context
    FullUri    = $true
}
$contentUri = New-AzStorageBlobSASToken @tokenParams

$guid=$(new-guid).guid
$PolicyConfig      = @{
    PolicyId      = $guid
    ContentUri    = $contentUri
    DisplayName   = $policyname
    Description   = $policyname
    Path          = $policypath
    Platform      = 'Linux'
    PolicyVersion = "1.0.0"
    Mode          = 'ApplyAndAutoCorrect'
  }
  
  if($tagname) {$policydata=New-GuestConfigurationPolicy @PolicyConfig -tag $tags} else {$policydata=New-GuestConfigurationPolicy @PolicyConfig}

  New-AzPolicyDefinition -Name $policyname -Policy $policydata.path


    }

    createpolicy -context $context -Policyname CreateFileNxScript -zipfilepath '/tmp/dscdev/configurations/CreateFileNxScript.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies'

createpolicy -context $context -Policyname nfile1scriptpol1 -zipfilepath '/tmp/dscdev/nfile1script.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf1"
createpolicy -context $context -Policyname nfile2 -zipfilepath '/tmp/dscdev/nfile2.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf2"
createpolicy -context $context -Policyname nfile3 -zipfilepath '/tmp/dscdev/nfile3.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf3"
createpolicy -context $context -Policyname nfile4 -zipfilepath '/tmp/dscdev/nfile4.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf4"
createpolicy -context $context -Policyname nfile5 -zipfilepath '/tmp/dscdev/nfile5.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf5"

createpolicy -context $context -Policyname nfile6 -zipfilepath '/tmp/dscdev/nfile6.zip' -containername 'machine-configuration' -policypath '/tmp/dscdev/policies' -tagname "cf6"


  $setParams = @{
    Container = 'machine-configuration'
    File      = '/tmp/dscdev/nfile1.zip'
    Context   = $context
}
$blob = Set-AzStorageBlobContent @setParams
$contentUri = $blob.ICloudBlob.Uri.AbsoluteUri

$startTime = Get-Date
$endTime   = $startTime.AddYears(3)

$tokenParams = @{
StartTime  = $startTime
ExpiryTime = $endTime
Container  = 'machine-configuration'
Blob       = 'nfile1.zip'
Permission = 'r'
Context    = $context
FullUri    = $true
}
$contentUri = New-AzStorageBlobSASToken @tokenParams

$guid=$(new-guid).guid
$PolicyConfig      = @{
PolicyId      = $guid
ContentUri    = $contentUri
DisplayName   = 'nfile1'
Description   = 'nfile1'
Path          = './policies/auditIfNotExists.json'
Platform      = 'Linux'
PolicyVersion = "1.0.0"
Mode          = 'ApplyAndAutoCorrect'
}

New-GuestConfigurationPolicy @PolicyConfig

New-AzPolicyDefinition -Name 'nfile1' -Policy '/tmp/dscdev/policies/policies/auditIfNotExists.json/nfile1_AuditIfNotExists.json'




$setParams = @{
    Container = 'machine-configuration'
    File      = '/tmp/dscdev/nfile1.zip'
    Context   = $context
}
$blob = Set-AzStorageBlobContent @setParams
$contentUri = $blob.ICloudBlob.Uri.AbsoluteUri

$startTime = Get-Date
$endTime   = $startTime.AddYears(3)

$tokenParams = @{
StartTime  = $startTime
ExpiryTime = $endTime
Container  = 'machine-configuration'
Blob       = 'nfile1.zip'
Permission = 'r'
Context    = $context
FullUri    = $true
}
$contentUri = New-AzStorageBlobSASToken @tokenParams

$guid=$(new-guid).guid
$PolicyConfig      = @{
PolicyId      = $guid
ContentUri    = $contentUri
DisplayName   = 'nfile1'
Description   = 'nfile1'
Path          = './policies/auditIfNotExists.json'
Platform      = 'Linux'
PolicyVersion = "1.0.0"
}

New-GuestConfigurationPolicy @PolicyConfig

New-AzPolicyDefinition -Name 'nfile1' -Policy '/tmp/dscdev/policies/policies/auditIfNotExists.json/nfile1_AuditIfNotExists.json'





$setParams = @{
    Container = 'machine-configuration'
    File      = '/tmp/dscdev/nfile4.zip'
    Context   = $context
}
$blob = Set-AzStorageBlobContent @setParams
$contentUri = $blob.ICloudBlob.Uri.AbsoluteUri

$startTime = Get-Date
$endTime   = $startTime.AddYears(3)

$tokenParams = @{
StartTime  = $startTime
ExpiryTime = $endTime
Container  = 'machine-configuration'
Blob       = 'nfile4.zip'
Permission = 'r'
Context    = $context
FullUri    = $true
}
$contentUri = New-AzStorageBlobSASToken @tokenParams

$guid=$(new-guid).guid
$PolicyConfig      = @{
PolicyId      = $guid
ContentUri    = $contentUri
DisplayName   = 'nfile4'
Description   = 'nfile4'
Path          = './policies/auditIfNotExists.json'
Platform      = 'Linux'
PolicyVersion = "1.0.0"
}

New-GuestConfigurationPolicy @PolicyConfig

New-AzPolicyDefinition -Name 'nfile4' -Policy '/tmp/dscdev/policies/policies/auditIfNotExists.json/nfile4_AuditIfNotExists.json'



$setParams = @{
    Container = 'machine-configuration'
    File      = '/tmp/dscdev/nfile5.zip'
    Context   = $context
}
$blob = Set-AzStorageBlobContent @setParams
$contentUri = $blob.ICloudBlob.Uri.AbsoluteUri

$startTime = Get-Date
$endTime   = $startTime.AddYears(3)

$tokenParams = @{
StartTime  = $startTime
ExpiryTime = $endTime
Container  = 'machine-configuration'
Blob       = 'nfile5.zip'
Permission = 'r'
Context    = $context
FullUri    = $true
}
$contentUri = New-AzStorageBlobSASToken @tokenParams

$guid=$(new-guid).guid
$PolicyConfig      = @{
PolicyId      = $guid
ContentUri    = $contentUri
DisplayName   = 'nfile5'
Description   = 'nfile5'
Path          = 'tmp/dscdev/policies/auditIfNotExists.json'
Platform      = 'Linux'
PolicyVersion = "1.0.0"
}

New-GuestConfigurationPolicy @PolicyConfig
New-AzPolicyDefinition -Name 'nfile5' -Policy '/tmp/dscdev/policies/policies/auditIfNotExists.json/nfile5_AuditIfNotExists.json'