
/home/azureuser/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

$env:PSModulePath += ":$pwd"

configuration nfile2 {

    import-dscresource -modulename nxtools
      
    nxscript nfile2script {
        setscript = @'
            
            $logfile = "/tmp/setdsclog.log"
            $scriptname="createfile_set.sh"
            $workingdir="/tmp/dscops"

            "[$(get-date)]starting set script" | out-file $logfile -Append -Force | out-null

            $scriptbody = @"
            touch nfile2.txt
"@

        if (!test-path $workingdir) { new-item $workingdir -ItemType Directory | out-null }
        $scriptbody | out-file "$workingdir/$scriptname" -Force
        "[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        "[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

        Invoke-NativeCommand -Executable 'bash' -Parameters @("$workingdir/$scriptname") | out-null

'@


testscript = @'

$logfile = "/tmp/testdsclog.log"
$scriptname="createfile_test.sh"
$workingdir="/tmp/dscops"

"[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null

$scriptbody = @"
if test -f /tmp/nfile2.txt; then
    echo "1"
else
    echo "0"
fi

"@

if (!test-path $workingdir) { new-item $workingdir -ItemType Directory | out-null }
$scriptbody | out-file "$workingdir/$scriptname" -Force
"[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
"[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

[bool]$res=$false
$res=Invoke-NativeCommand -Executable 'bash' -Parameters @("$workingdir/$scriptname") | out-null
return $res
'@


getscript = ""

    }
}

nfile2

rename-item ./nfile2/localhost.mof  nfile2.mof
