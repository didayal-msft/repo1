#steps to perform after mof file is created.
# Create a package that will only audit compliance

/tmp/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

$params = @{
    Name          = 'nfile1script'
    Configuration = '/tmp/dscdev/configurations/nfile1script/nfile1script.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose

$params = @{
    Name          = 'CreateFileNxScript'
    Configuration = '/tmp/dscdev/configurations/CreateFileNxScript/CreateFileNxScript.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose


$params = @{
    Name          = 'CreateFileNxScriptbash'
    Configuration = '/tmp/dscdev/configurations/CreateFileNxScriptbash/CreateFileNxScriptbash.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose


<#
$params = @{
    Name          = 'nfile2'
    Configuration = './configurations/nfile2/nfile2.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose


$params = @{
    Name          = 'nfile3'
    Configuration = './configurations/nfile3/nfile3.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose



$params = @{
    Name          = 'nfile4'
    Configuration = './configurations/nfile4/nfile4.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose


$params = @{
    Name          = 'nfile5'
    Configuration = './configurations/nfile5/nfile5.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose

$params = @{
    Name          = 'nfile6'
    Configuration = './configurations/nfile6/nfile6.mof'
    Type          = 'AuditAndSet'
    Force         = $true
}
New-GuestConfigurationPackage @params -verbose


Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/nfile1script.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/nfile1script.zip


Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/configurations/CreateFileNxScript.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/configurations/CreateFileNxScript.zip

Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/configurations/CreateFileNxScriptbash.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/configurations/CreateFileNxScriptbash.zip


Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/nfile3.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/nfile3.zip

Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/nfile4.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/nfile4.zip

Get-GuestConfigurationPackageComplianceStatus -Path /tmp/dscdev/nfile5.zip
Start-GuestConfigurationPackageRemediation -Path /tmp/dscdev/nfile5.zip
#>

get-help Get-GuestConfigurationPackageComplianceStatus -full
