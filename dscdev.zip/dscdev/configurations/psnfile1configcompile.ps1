
/tmp/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

$env:PSModulePath += ":$pwd"

configuration psnfile1script {

    import-dscresource -modulename nxtools
    import-dscresource -modulename psdscresources
      
    nxscript psnfile1script {
        setscript = @'
            
            
            $scriptname="psnfile1script_set.sh"
            $workingdir="/tmp/dsc-ops"
            $logfile = "$workingdir/setdsclog.log"
            if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
     

      
        try {
        
"empty" | out-file "$workingdir/psnfile1script.txt" -force

        }
        catch
        {
            "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
        }

'@


testscript = @'
$scriptname="psnfile1script_test.sh"
$workingdir="/tmp/dsc-ops"
$logfile = "$workingdir/testdsclog.log"
if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
"[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null

try{


$res=$false
$res=$(test-path "$workingdir/psnfile1script.txt")
"[$(get-date)]complete and returning $res" | out-file $logfile -Append -Force | out-null

return $res
    }
catch
{
    "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
    return $false
}
'@


getscript = ""

    }
}

psnfile1script

rename-item ./psnfile1script/localhost.mof  psnfile1script.mof


<#


$scriptname="createfile_get.sh"
$workingdir="/tmp/dsc-ops"
$logfile = "$workingdir/getdsclog.log"
if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
"[$(get-date)]starting get script" | out-file $logfile -Append -Force | out-null

$scriptbody = @"
ls /tmp/psnfil1.txt
"@

try{
$scriptbody | out-file "$workingdir/$scriptname" -Force

"[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
"[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null


$res=invoke-expression "sudo sh $workingdir/$scriptname" 
return $res
    }
    catch
    {
        "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
        return @{"scriptfailed" = "failed $_"}
    }
#>