
/tmp/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

$env:PSModulePath += ":$pwd"

configuration nfile1script {

    import-dscresource -modulename nxtools
    import-dscresource -modulename psdscresources
      
    nxscript nfile1script {
        setscript = @'
            
            
            $scriptname="createfile1_set.sh"
            $workingdir="/tmp/dsc-ops"
            $logfile = "$workingdir/setdsclog.log"
            if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
            

            $scriptbody = @"
touch /tmp/dscfile1.txt
"@

        "[$(get-date)]saving setscript to $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        $scriptbody | out-file "$workingdir/$scriptname" -Force
        
        try {
        

        "[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        "[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

        invoke-expression "sudo sh $workingdir/$scriptname" | out-null

        }
        catch
        {
            "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
        }

'@


testscript = @'
$scriptname="createfile1_test.sh"
$workingdir="/tmp/dsc-ops"
$logfile = "$workingdir/testdsclog.log"
if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
"[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null

$scriptbody = @"
if test -f /tmp/dscfile1.txt; then
    echo "1"
else
    echo "0"
fi

"@

try{
$scriptbody | out-file "$workingdir/$scriptname" -Force

"[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
"[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

[int]$res=0
$res=invoke-expression "sudo sh $workingdir/$scriptname"
"[$(get-date)]complete and returning $res" | out-file $logfile -Append -Force | out-null

return [bool]$res
    }
catch
{
    "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
    return $false
}
'@


getscript = ""

    }
}

nfile1script

rename-item ./nfile1script/localhost.mof  nfile1script.mof


<#


$scriptname="createfile_get.sh"
$workingdir="/tmp/dsc-ops"
$logfile = "$workingdir/getdsclog.log"
if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
"[$(get-date)]starting get script" | out-file $logfile -Append -Force | out-null

$scriptbody = @"
ls /tmp/nfile1.txt
"@

try{
$scriptbody | out-file "$workingdir/$scriptname" -Force

"[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
"[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null


$res=invoke-expression "sudo sh $workingdir/$scriptname" 
return $res
    }
    catch
    {
        "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
        return @{"scriptfailed" = "failed $_"}
    }
#>