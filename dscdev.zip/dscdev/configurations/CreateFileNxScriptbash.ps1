<#
    .DESCRIPTION
        This example shows how to create a file with [nxScript].

    .NOTES
        Because the resources are class based, you can also test the resource this way:

        using module nxtools # assuming it's available via $Env:PSModulePath.

        $rsrc = [nxScript]@{
            GetScript = {
                # Implementation...
            }
            TestScript = {
                # Implementation...
            }
            SetScript = {
                # Implementation...
            }
        }

        $rsrc.Get().Reasons
        $rsrc.Set()
        $rsrc.Get()
#>

configuration CreateFileNxScriptbash
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $FilePath,

        [Parameter(Mandatory = $true)]
        [ValidateNotNullOrEmpty()]
        [String]
        $FileContent
    )

    Import-DscResource -ModuleName 'nxtools'

    nxScript MyScript
    {
        GetScript = {
            $Reason = [Reason]::new()
            $Reason.Code = "Script:Script:FileMissing"
            $Reason.Phrase = "File does not exist"

            if (Test-Path -Path "/tmp/dsc-ops/CreateFileNxScriptbash.txt")
            {
                $text = "$(Get-Content -Path "/tmp/dsc-ops/CreateFileNxScriptbash.txt" -Raw)".Trim()
                if ($text -eq $using:FileContent)
                {
                    $Reason.Code = "Script:Script:Success"
                    $Reason.Phrase = "File exists with correct content"
                }
                else
                {
                    $Reason.Code = "Script:Script:ContentMissing"
                    $Reason.Phrase = "File exists but has incorrect content"
                }
            }

            return @{
                Reasons = @($Reason)
            }
        }

        TestScript = {
            $scriptname="CreateFileNxScriptbash_test.sh"
        $workingdir="/tmp/dsc-ops"
        $logfile = "$workingdir/CreateFileNxScriptbash_test.log"
        if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
        "[$(get-date)]starting test script" | out-file $logfile -Append -Force | out-null
        
        $scriptbody = @"
        if test -f /tmp/dsc-ops/CreateFileNxScriptbash.txt; then
            echo "1"
        else
            echo "0"
        fi
        
"@
        
        try{
        $scriptbody | out-file "$workingdir/$scriptname" -Force
        
        "[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        "[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        
        [int]$res=0
        $res=invoke-expression "sudo sh $workingdir/$scriptname"
        "[$(get-date)]complete and returning $res" | out-file $logfile -Append -Force | out-null
        
        return [bool]$res
            }
        catch
        {
            "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
            return $false
        }
        }



        SetScript = {
            $scriptname="CreateFileNxScriptbash_set.sh"
            $workingdir="/tmp/dsc-ops"
            $logfile = "$workingdir/CreateFileNxScriptbash_set.log"
            if (-not (test-path $workingdir)) { new-item $workingdir -ItemType Directory | out-null }
            

            $scriptbody = @"
touch /tmp/dsc-ops/CreateFileNxScriptbash.txt
"@

        "[$(get-date)]saving setscript to $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        $scriptbody | out-file "$workingdir/$scriptname" -Force
        
        try {
        

        "[$(get-date)]created file $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null
        "[$(get-date)]executing script $workingdir/$scriptname" | out-file $logfile -Append -Force | out-null

        $null = invoke-expression "sudo sh $workingdir/$scriptname"

        }
        catch
        {
            "[$(get-date)]failed $_" | out-file $logfile -Append -Force | out-null
        }

        }
    }
}

#/tmp/dscdev/prereqsauthoringvm/pre-reqs.ps1 -install $false

#$env:PSModulePath += ":$pwd"
CreateFileNxScriptbash -FilePath "/tmp/dsc-ops/CreateFileNxScriptbash.txt" -FileContent "testingdsc"

rename-item ./CreateFileNxScriptbash/localhost.mof  CreateFileNxScriptbash.mof