
# guest configuration agent version 1.29.24 min or arc agent 1.10.0 min,

# install Powershell 7
# https://learn.microsoft.com/en-us/powershell/scripting/install/install-ubuntu?view=powershell-7.3
# Update the list of packages
# sudo apt-get update
# # Install pre-requisite packages.
# sudo apt-get install -y wget apt-transport-https software-properties-common
# # Download the Microsoft repository GPG keys
# wget -q "https://packages.microsoft.com/config/ubuntu/$(lsb_release -rs)/packages-microsoft-prod.deb"
# # Register the Microsoft repository GPG keys
# sudo dpkg -i packages-microsoft-prod.deb
# # Delete the the Microsoft repository GPG keys file
# rm packages-microsoft-prod.deb
# # Update the list of packages after we added packages.microsoft.com
# sudo apt-get update
# # Install PowerShell
# sudo apt-get install -y powershell
# # Start PowerShell
# pwsh


# Install DSCv3 
# When compiling configurations for Linux install the prerelease version 3.0.0.
# Install-Module -Name PSDesiredStateConfiguration -AllowPrerelease

# https://learn.microsoft.com/en-us/azure/governance/machine-configuration/how-to-set-up-authoring-environment
# Install the machine configuration DSC resource module from PowerShell Gallery
# Install-Module -Name GuestConfiguration
# The GuestConfiguration module is only available on Ubuntu 18. However, the package and policies produced by the module can be used on any Linux distribution and version supported in Azure or Arc.


#https://learn.microsoft.com/en-us/azure/governance/machine-configuration/how-to-create-package
#For Linux, you need to create a custom DSC resource module using PowerShell classes. The article Writing a custom DSC resource with PowerShell classes includes a full example of a custom resource and configuration, tested with machine configuration.
#https://learn.microsoft.com/en-us/powershell/dsc/tutorials/create-class-based-resource?view=dsc-2.0&viewFallbackFrom=dsc-3.0

 <# decision helping facts:
https://learn.microsoft.com/en-us/azure/governance/machine-configuration/migrate-from-dsc-extension#older-nx-modules-for-linux-dsc-arent-compatible-with-dscv3
older nx modules not supported. they were c based and machine configuration policy does not support

new nxtools module is available but has limited functionality
https://github.com/azure/nxtools

Install-Module -Name nxtools

DSC Resources
nxFile: Manage a file or a folder to make sure it's present/absent, its content, mode, owner group.
nxGroup: Simple resource to manage [nxLocalGroup] and group members.
nxUser: Simple resource to manage [nxLocalUser] accounts.
nxPackage: Audit (for now) whether a package is installed or not in a system (currently supports apt only).
nxFileLine: Ensure an exact line is present/absent in a file, and remediate by appending, inserting, deleting as needed.
nxFileContentReplace: Replace the content in a file if a pattern is found.
Guest Configuration Packages
No90CloudInitUserAllowdNoPasswdInSudoers: Ensure no user are granted NOPASSWD in sudoers file /etc/sudoers.d/90-cloud-init-users.
InstalledApplicationLinux [Audit]: Ensure the list of packages is installed (dpkg only)
LinuxGroupsMustExclude [AuditAndSet]: List of users that must be excluded from a group.
LinuxGroupsMustInclude [AuditAndSet]: List of users that must be included in a group.
NotInstalledApplicationLinux [Audit]: Ensure the list of packages is not installed (dpkg only)
PasswordPolicy_msid110 [Audit]: Remote connections from accounts with empty passwords should be disabled.
PasswordPolicy_msid121 [Audit]: file /etc/passwd permissions should be 0644
PasswordPolicy_msid232 [Audit]: Ensure there are no accounts without passwords.


#>

$testscript = @'
File=/tmp/dscdev/setworks.txt  
if test -f "$File"; 
then  
#echo "$File exist " 
echo 1
else
#echo "does not exist $File" 
echo 0
fi  
'@


$setscript = "'checksetworks' | out-file /tmp/dscdev/setworks.txt"

Invoke-Expression "bash -c '$testscript'"