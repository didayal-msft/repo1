[DscResource()]
class nxscriptclass {
    [DscProperty(Key)] [customscriptScope]
    $ConfigurationScope

    [DscProperty(Mandatory)] [string]
    $getscript

    [DscProperty(Mandatory)][string]
    $setscript

    [DscProperty(Mandatory)][string]
    $testscript
    
    [DscProperty()]
    [Reason[]] $Reasons

    [bool] Test() {
        #$CurrentState = $this.Get()
        #write-host $this.testscript
        $rnd = Get-Random -Minimum 100 -Maximum 999
        "$($this.testscript)" | out-file "\tmp\testscript$rnd$(".sh")" -force
        Set-Location \tmp
        [int]$res = Invoke-Expression "sudo sh testscript$rnd.sh"
        Remove-Item "\tmp\testscript$rnd$(".sh")" -force
        return $res
    }

    [void] Set() {
        $rnd = Get-Random -Minimum 100 -Maximum 999
        "$($this.setscript)" | out-file "\tmp\setscript$rnd$(".sh")" -force
        Set-Location \tmp
        Invoke-Expression "sudo sh setscript$rnd.sh" | out-null
        Remove-Item "\tmp\setscript$rnd$(".sh")" -force
            
    }
    [nxscriptclass] Get() {
        if ([string]::IsNullOrEmpty($this.GetScript)) {
            $Reason = [Reason]::new()
            $Reason.Code = "Script:Script:GetScriptNotDefined"
            $Reason.Phrase = "No Get Script defined"
            $this.Reasons = @($Reason)
            return $this
        }
        else {
            $rnd = Get-Random -Minimum 100 -Maximum 999
            "$($this.getscript)" | out-file "\tmp\getscript$rnd$(".sh")" -force
            Set-Location \tmp
            try {
                $res = Invoke-Expression "sudo sh getscript$rnd.sh" 
                $Reason = [Reason]::new()
                $Reason.Code = "GetScriptOutput"
                $Reason.Phrase = "$res"
                $this.Reasons = @($Reason)
                return $this
            }
            catch {
                $Reason = [Reason]::new()
                $Reason.Code = "GetScriptReturnedError"
                $Reason.Phrase = "$($_)"
                $this.Reasons = @($Reason)
                return $this
            }
            finally {
                <#Do this after the try block regardless of whether an exception occurred or not#>
                Remove-Item "\tmp\getscript$rnd$(".sh")" -force
            }
           
  
     


        }
       
    }
      
}

class Reason {
    [DscProperty()]
    [string] $Code
    
    [DscProperty()]
    [string] $Phrase
}

enum customscriptScope {
    Machine
    User
}
